import React from 'react';
import { ProductItem } from '../types';
import {
  STORE_ASSETS,
  MOBILE_LEGEND_DIAMOND_PRODUCTS,
  MOBILE_LEGEND_PASS_PRODUCTS,
  formatRupiah,
  getDiscountPercentage,
} from '../data/products';
import { TopBackButton } from './TopBackButton';
import { Promo1111Banner } from './Promo1111Banner';
import { Check, Sparkles, Gem, ShieldCheck, Flame } from 'lucide-react';

interface MobileLegendViewProps {
  selectedProduct: ProductItem | null;
  onSelectProduct: (product: ProductItem) => void;
  onBackToHome: () => void;
}

export const MobileLegendView: React.FC<MobileLegendViewProps> = ({
  selectedProduct,
  onSelectProduct,
  onBackToHome,
}) => {
  return (
    <div className="pb-36 pt-3 max-w-4xl mx-auto px-4 sm:px-6">
      {/* Prominent Top Back Bar */}
      <TopBackButton onBack={onBackToHome} gameName="Mobile Legends" />

      {/* 11.11 Mega Sale Banner */}
      <Promo1111Banner gameName="Mobile Legends" />

      {/* Top Banner & Header (2.4:1 Aspect Ratio) */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-md mb-6">
        <div className="relative aspect-[1942/809] w-full overflow-hidden bg-slate-100 dark:bg-slate-950">
          <img
            src={STORE_ASSETS.mobilelegendBanner}
            alt="Mobile Legends Banner"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-4 sm:p-5 relative z-10 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-slate-950 dark:text-white tracking-tight">
                  Mobile Legends Top Up
                </h1>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-sm">
                  <Flame className="w-3 h-3 fill-amber-200 mr-0.5" />
                  11.11 SALE
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-400/30 backdrop-blur-md">
                  <ShieldCheck className="w-3 h-3 mr-1" />
                  Resmi Moonton
                </span>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-950 dark:text-slate-300 mt-1 leading-relaxed">
                Top up Diamond dan Weekly Diamond Pass Mobile Legends resmi dengan harga promo diskon 11.11 termurah di Vrena Store.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Title */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-6 h-6 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shadow-xs">
          1
        </div>
        <h2 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
          Pilih Nominal Top Up
        </h2>
      </div>

      {/* SECTION A: Weekly Pass */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2.5">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            A. Weekly Pass
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {MOBILE_LEGEND_PASS_PRODUCTS.map((product) => {
            const isSelected = selectedProduct?.id === product.id;
            const discount = getDiscountPercentage(product.price, product.originalPrice);

            return (
              <div
                key={product.id}
                onClick={() => onSelectProduct(product)}
                className={`relative cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'border-amber-500 bg-amber-500/10 ring-1 ring-amber-500 shadow-md'
                    : 'border-slate-200 bg-white hover:border-amber-400 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-slate-700 dark:hover:bg-slate-800/80 shadow-xs'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-slate-100 dark:bg-slate-950 p-1 flex items-center justify-center border border-slate-200 dark:border-slate-800 shrink-0">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow"
                    />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">
                      {product.name}
                    </h4>
                    <div className="flex items-baseline gap-1.5 mt-0.5 font-mono">
                      <span className="text-xs sm:text-sm font-black text-amber-600 dark:text-blue-400">
                        {formatRupiah(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 line-through font-semibold">
                          {formatRupiah(product.originalPrice)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {discount && (
                    <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-red-600 text-white">
                      -{discount}%
                    </span>
                  )}
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION B: Diamond */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2.5">
          <Gem className="w-4 h-4 text-amber-500 dark:text-cyan-400" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            B. Diamond Mobile Legends
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {MOBILE_LEGEND_DIAMOND_PRODUCTS.map((product) => {
            const isSelected = selectedProduct?.id === product.id;
            const discount = getDiscountPercentage(product.price, product.originalPrice);

            return (
              <div
                key={product.id}
                onClick={() => onSelectProduct(product)}
                className={`relative cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-500 bg-amber-500/10 ring-1 ring-amber-500 shadow-md'
                    : 'border-slate-200 bg-white hover:border-amber-400 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900/90 dark:hover:border-slate-700 dark:hover:bg-slate-800/80 shadow-xs'
                }`}
              >
                {/* 11.11 Discount Badge */}
                {discount && (
                  <div className="absolute top-2 right-2">
                    <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-red-600 text-white shadow-xs">
                      -{discount}%
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-2.5 mb-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-950 p-1 flex items-center justify-center border border-slate-200 dark:border-slate-800 shrink-0">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow"
                    />
                  </div>
                  <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-tight">
                    {product.name}
                  </h4>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-end justify-between font-mono">
                  <div>
                    <div className="text-xs sm:text-sm font-black text-amber-600 dark:text-blue-400">
                      {formatRupiah(product.price)}
                    </div>
                    {product.originalPrice && (
                      <div className="text-[10px] sm:text-[11px] text-slate-400 dark:text-slate-500 line-through font-semibold">
                        {formatRupiah(product.originalPrice)}
                      </div>
                    )}
                  </div>

                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
