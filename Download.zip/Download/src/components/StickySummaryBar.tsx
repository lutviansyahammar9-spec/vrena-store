import React from 'react';
import { createPortal } from 'react-dom';
import { ProductItem } from '../types';
import { formatRupiah } from '../data/products';
import { ArrowRight, Sparkles, X, CheckCircle2 } from 'lucide-react';

interface StickySummaryBarProps {
  selectedProduct: ProductItem | null;
  onContinue: () => void;
  onClear?: () => void;
}

export const StickySummaryBar: React.FC<StickySummaryBarProps> = ({
  selectedProduct,
  onContinue,
  onClear,
}) => {
  if (!selectedProduct || typeof document === 'undefined') {
    return null;
  }

  const content = (
    <aside
      aria-label="Keranjang Belanja Mengambang"
      className="fixed bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-[100] w-full max-w-[92vw] sm:max-w-xl px-2 pointer-events-none animate-in fade-in zoom-in-95 slide-in-from-bottom-6 duration-300"
    >
      <div className="pointer-events-auto relative group overflow-hidden rounded-full bg-white/95 dark:bg-slate-950/95 backdrop-blur-2xl border border-purple-200/90 dark:border-amber-400/40 shadow-[0_20px_50px_rgba(147,51,234,0.18),0_4px_20px_rgba(0,0,0,0.08)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_35px_rgba(245,158,11,0.25)] ring-1 ring-purple-100 dark:ring-amber-400/20 px-3.5 py-2 sm:px-4 sm:py-2.5 flex items-center justify-between gap-2.5 sm:gap-4 transition-all">
        {/* Ambient Glow inside bubble */}
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-indigo-500/5 to-purple-500/10 dark:from-amber-500/15 dark:via-yellow-500/10 dark:to-orange-500/15 pointer-events-none" />

        {/* Left Side: Product Avatar & Title & Price */}
        <div className="relative z-10 flex items-center gap-2.5 sm:gap-3.5 min-w-0 flex-1">
          {/* Avatar with glowing border */}
          <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-slate-100 dark:bg-slate-900 border-2 border-purple-300 dark:border-amber-400/60 p-1 flex items-center justify-center shrink-0 shadow-md">
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              className="max-h-full max-w-full object-contain filter drop-shadow"
            />
            <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-emerald-500 text-white dark:text-slate-950 flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow">
              <CheckCircle2 className="w-3 h-3 text-white dark:text-slate-950 stroke-[3]" />
            </div>
          </div>

          {/* Details */}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 leading-none">
              <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-purple-700 bg-purple-100/90 dark:text-amber-300 dark:bg-amber-500/15 px-2 py-0.5 rounded-full border border-purple-200 dark:border-amber-400/25 flex items-center gap-0.5 shadow-xs">
                <Sparkles className="w-2.5 h-2.5 text-purple-600 dark:text-amber-300" />
                11.11 Promo
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate hidden sm:inline">
                Siap Checkout
              </span>
            </div>

            <p className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white truncate mt-1">
              {selectedProduct.name}
            </p>

            {/* Cart Bubble Price: Light mode = Hitam perpaduan ungu, Dark mode = Putih perpaduan gold */}
            <div className="flex items-center gap-1.5 mt-0.5 font-mono">
              <div className="inline-flex items-baseline gap-0.5 px-2.5 py-0.5 rounded-full bg-purple-50/90 border border-purple-300/80 text-slate-950 dark:bg-slate-900/95 dark:border-amber-400/60 dark:text-white shadow-xs">
                {/* Currency symbol: purple in light, gold in dark */}
                <span className="text-[11px] sm:text-xs font-black text-purple-700 dark:text-amber-400">
                  Rp
                </span>
                {/* Price digits: black in light, white in dark */}
                <span className="text-xs sm:text-sm font-black text-slate-950 dark:text-white whitespace-nowrap">
                  {Math.round(selectedProduct.price).toLocaleString('id-ID')}
                </span>
              </div>

              {selectedProduct.originalPrice && (
                <span className="text-[10px] sm:text-[11px] text-slate-400 dark:text-amber-200/50 line-through font-semibold whitespace-nowrap">
                  {formatRupiah(selectedProduct.originalPrice)}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Continue Button & Deselect Option */}
        <div className="relative z-10 flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={onContinue}
            className="group/btn px-4 sm:px-6 py-2.5 sm:py-3 rounded-full font-black text-xs sm:text-sm tracking-wide text-white bg-gradient-to-r from-purple-700 via-indigo-600 to-purple-800 hover:from-purple-600 hover:to-indigo-500 shadow-lg shadow-purple-600/30 dark:from-amber-500 dark:via-amber-400 dark:to-yellow-500 dark:hover:from-amber-400 dark:hover:to-yellow-400 dark:text-slate-950 dark:shadow-amber-500/35 flex items-center gap-1.5 sm:gap-2 transition-all duration-200 hover:scale-[1.03] active:scale-[0.97] cursor-pointer whitespace-nowrap"
          >
            <span>Lanjutkan</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
          </button>

          {onClear && (
            <button
              onClick={onClear}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 border border-slate-300/80 dark:bg-slate-800/90 dark:hover:bg-slate-700/90 dark:text-slate-400 dark:hover:text-white dark:border-slate-700/60 flex items-center justify-center transition-colors cursor-pointer shadow-sm"
              title="Batalkan pilihan"
              aria-label="Batalkan pilihan produk"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </aside>
  );

  return createPortal(content, document.body);
};
