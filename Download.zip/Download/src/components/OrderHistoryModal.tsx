import React, { useState } from 'react';
import { OrderRecord } from '../types';
import { formatRupiah, formatAccountDisplay } from '../data/products';
import { History, X, Clock, Trash2, CheckCircle2, XCircle, RefreshCw, Copy, Check, AlertCircle } from 'lucide-react';

interface OrderHistoryModalProps {
  orders: OrderRecord[];
  onClose: () => void;
  onClearHistory: () => void;
  onSync?: () => Promise<void>;
}

export const OrderHistoryModal: React.FC<OrderHistoryModalProps> = ({
  orders,
  onClose,
  onClearHistory,
  onSync,
}) => {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copiedTicket, setCopiedTicket] = useState<string | null>(null);

  const handleCopyTicket = (ticket: string) => {
    navigator.clipboard.writeText(ticket);
    setCopiedTicket(ticket);
    setTimeout(() => setCopiedTicket(null), 2000);
  };

  const handleManualSync = async () => {
    if (!onSync || isSyncing) return;
    setIsSyncing(true);
    try {
      await onSync();
    } finally {
      setTimeout(() => setIsSyncing(false), 600);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col rounded-3xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-900/95 shadow-2xl animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-indigo-500/15 text-amber-600 dark:text-indigo-400 flex items-center justify-center">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                Riwayat Pesanan
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Status terhubung langsung dengan Discord Bot & Database
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onSync && (
              <button
                type="button"
                onClick={handleManualSync}
                disabled={isSyncing}
                title="Perbarui Status Pesanan dari Server"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-600 dark:text-indigo-400' : ''}`} />
                <span className="hidden sm:inline">{isSyncing ? 'Memperbarui...' : 'Sinkronkan'}</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Orders list */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          {orders.length === 0 ? (
            <div className="py-12 text-center">
              <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-400 dark:text-slate-500">
                <History className="w-8 h-8" />
              </div>
              <h4 className="text-base font-bold text-slate-800 dark:text-white">
                Belum Ada Riwayat Pesanan
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                Pesanan top up yang kamu buat akan otomatis tercatat dan tersimpan di sini.
              </p>
            </div>
          ) : (
            orders.map((order) => {
              const ticketDisplay = order.ticketNumber || order.orderId;

              return (
                <div
                  key={order.orderId || ticketDisplay}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70 p-4 sm:p-5 space-y-3 shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-200/80 dark:border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 bg-amber-100 dark:bg-indigo-950/60 px-2.5 py-1 rounded-md border border-amber-300 dark:border-indigo-800/60">
                        <span className="font-mono text-xs font-bold text-amber-800 dark:text-indigo-300 select-all">
                          {ticketDisplay}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyTicket(ticketDisplay)}
                          title="Salin Nomor Tiket"
                          className="p-0.5 rounded text-amber-700 dark:text-indigo-300 hover:text-amber-900 dark:hover:text-white transition-colors cursor-pointer"
                        >
                          {copiedTicket === ticketDisplay ? (
                            <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {order.createdAt}
                      </span>
                    </div>

                    {/* Status Pill Badge */}
                    {order.status === 'Pembayaran Berhasil' ? (
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-500/30">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Pembayaran Berhasil</span>
                      </div>
                    ) : order.status === 'Pembayaran Ditolak' ? (
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-400 border border-rose-300 dark:border-rose-500/30">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Pembayaran Ditolak</span>
                      </div>
                    ) : (
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-500/30">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Menunggu Proses Pesanan</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">Game & Produk:</span>
                      <strong className="text-slate-900 dark:text-white text-sm">
                        {order.gameName} — {order.productName}
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">Akun Tujuan:</span>
                      <strong className="text-slate-900 dark:text-white text-sm">
                        {formatAccountDisplay(order.accountData)}
                      </strong>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200/80 dark:border-slate-800/80 text-xs">
                    <span className="text-slate-500 dark:text-slate-400">
                      Metode: <strong className="text-slate-800 dark:text-white">{order.paymentMethodName}</strong>
                    </span>

                    <span className="text-base font-extrabold text-amber-600 dark:text-emerald-400">
                      {formatRupiah(order.price)}
                    </span>
                  </div>

                  {/* Rejection Details & Refund Notice */}
                  {order.status === 'Pembayaran Ditolak' && (
                    <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/70 border border-rose-200 dark:border-rose-900/60 text-xs space-y-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-rose-700 dark:text-rose-400">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>Alasan Ditolak:</span>
                      </div>
                      <p className="text-[11px] text-slate-800 dark:text-slate-200 pl-5 italic font-medium">
                        &ldquo;{order.rejectReason || 'Pembayaran tidak memenuhi ketentuan verifikasi.'}&rdquo;
                      </p>
                      <div className="pt-1 border-t border-rose-200 dark:border-rose-900/60 flex flex-wrap justify-between items-center text-[10px] text-rose-700 dark:text-rose-300">
                        <strong>Dana akan dikembalikan sesuai nominal.</strong>
                        <span>Diverifikasi oleh: VrenaStore</span>
                      </div>
                    </div>
                  )}

                  {order.status === 'Pembayaran Berhasil' && (
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-900 p-2 rounded-lg flex flex-wrap justify-between gap-1">
                      <span>Diverifikasi oleh: <strong className="text-emerald-600 dark:text-emerald-400">VrenaStore</strong></span>
                      {order.processedAt && <span>Waktu: {order.processedAt}</span>}
                    </div>
                  )}

                  {order.paymentProofUrl && (
                    <div className="pt-1 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <span>Bukti transfer terlampir:</span>
                      <span className="font-medium text-slate-700 dark:text-slate-300 truncate max-w-[200px]">
                        {order.paymentProofName || 'bukti_transfer.jpg'}
                      </span>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        {orders.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            {confirmDelete ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-rose-500 font-semibold">Hapus semua riwayat?</span>
                <button
                  type="button"
                  onClick={() => {
                    onClearHistory();
                    setConfirmDelete(false);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition-colors cursor-pointer"
                >
                  Ya, Hapus
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                >
                  Batal
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Semua Riwayat</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white shadow transition-colors cursor-pointer"
            >
              Tutup
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
