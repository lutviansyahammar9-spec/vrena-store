import React, { useState } from 'react';
import { ViewState } from '../types';
import {
  Sun,
  Moon,
  Gamepad2,
  Home,
  Receipt,
  Menu,
  X,
  ChevronDown,
  Flame,
  Sparkles,
  Swords,
  Trophy,
  Zap,
  Crosshair,
  Search,
} from 'lucide-react';

interface NavbarProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  orderCount: number;
  onOpenHistory: () => void;
  onOpenTicketFinder: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  isDark,
  onToggleTheme,
  orderCount,
  onOpenHistory,
  onOpenTicketFinder,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [gamesDropdownOpen, setGamesDropdownOpen] = useState(false);

  const handleNav = (view: ViewState) => {
    onNavigate(view);
    setMobileMenuOpen(false);
    setGamesDropdownOpen(false);
  };

  const navGames = [
    { id: 'freefire' as ViewState, name: 'Free Fire', tag: 'FF', icon: <Flame className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'roblox' as ViewState, name: 'Roblox', tag: 'RBX', icon: <Sparkles className="w-3.5 h-3.5 text-rose-400" /> },
    { id: 'mobilelegend' as ViewState, name: 'Mobile Legends', tag: 'MLBB', icon: <Swords className="w-3.5 h-3.5 text-blue-400" /> },
    { id: 'fcmobile' as ViewState, name: 'FC Mobile', tag: 'FCM', icon: <Trophy className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'pokemonunite' as ViewState, name: 'Pokemon Unite', tag: 'UNITE', icon: <Zap className="w-3.5 h-3.5 text-purple-400" /> },
    { id: 'bloodstrike' as ViewState, name: 'Blood Strike', tag: 'BS', icon: <Crosshair className="w-3.5 h-3.5 text-red-400" /> },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-2xl border-b transition-colors duration-300 bg-white/95 dark:bg-slate-950/85 border-slate-200 dark:border-slate-800/80 text-slate-800 dark:text-slate-100 shadow-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Left: Brand Identity */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => handleNav('home')}
              className="flex items-center gap-2.5 group focus:outline-none cursor-pointer text-left"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-400 p-[1.5px] shadow-lg shadow-amber-500/25 group-hover:scale-105 transition-transform duration-200 shrink-0">
                <div className="w-full h-full rounded-[10px] bg-slate-950 flex items-center justify-center">
                  <Gamepad2 className="w-4 h-4 text-amber-400 group-hover:text-white transition-colors" />
                </div>
              </div>

              <div>
                <div className="flex items-center gap-1.5 leading-none">
                  <span className="font-black text-lg sm:text-xl tracking-wider text-slate-900 dark:text-white">
                    VRENA
                  </span>
                  <span className="text-[10px] font-black tracking-widest uppercase text-amber-700 dark:text-amber-400 px-1 py-0.2 rounded bg-amber-500/15 border border-amber-400/30">
                    STORE
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-tight mt-0.5">
                  Top Up Game Resmi & Terpercaya
                </p>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1.5 pl-2 border-l border-slate-200 dark:border-slate-800/80">
              <button
                onClick={() => handleNav('home')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  currentView === 'home'
                    ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/30'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/60'
                }`}
              >
                <Home className="w-3.5 h-3.5" />
                <span>Beranda</span>
              </button>

              {/* Games Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setGamesDropdownOpen(!gamesDropdownOpen)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    navGames.some((g) => g.id === currentView)
                      ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Gamepad2 className="w-3.5 h-3.5 text-amber-500 dark:text-cyan-400" />
                  <span>Katalog Game</span>
                  <ChevronDown className="w-3.5 h-3.5 opacity-70" />
                </button>

                {gamesDropdownOpen && (
                  <div
                    onMouseLeave={() => setGamesDropdownOpen(false)}
                    className="absolute left-0 mt-2 w-56 rounded-2xl bg-white dark:bg-slate-900/98 border border-slate-200 dark:border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-xl"
                  >
                    <div className="text-[10px] uppercase font-black text-slate-400 dark:text-slate-500 px-3 py-1 tracking-wider">
                      Pilihan Game
                    </div>
                    {navGames.map((game) => (
                      <button
                        key={game.id}
                        onClick={() => handleNav(game.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                          currentView === game.id
                            ? 'bg-amber-500 text-slate-950 font-black'
                            : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800/80'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {game.icon}
                          <span>{game.name}</span>
                        </div>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800/90 text-slate-600 dark:text-slate-300">
                          {game.tag}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </nav>
          </div>

          {/* Right: Actions (Ticket Finder, Order History & Theme Switch) */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Ticket Finder Button */}
            <button
              onClick={onOpenTicketFinder}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl text-xs font-bold text-amber-900 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/20 border border-amber-300 dark:border-amber-500/30 transition-all cursor-pointer shadow-xs"
              title="Cari & Lacak Tiket Pesanan"
            >
              <Search className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span className="hidden md:inline">Lacak Tiket</span>
            </button>

            {/* Order History Button */}
            <button
              onClick={onOpenHistory}
              className="relative flex items-center gap-2 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white hover:bg-slate-50 dark:bg-slate-900/90 dark:hover:bg-slate-800/90 border border-slate-200 dark:border-slate-800 hover:border-amber-400 transition-all cursor-pointer shadow-xs"
              title="Cek Riwayat Pesanan"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-500 dark:text-cyan-400" />
              <span className="hidden sm:inline">Riwayat</span>
              {orderCount > 0 && (
                <span className="flex items-center justify-center min-w-[18px] h-[18px] px-1 text-[10px] font-black bg-amber-500 text-slate-950 rounded-full">
                  {orderCount}
                </span>
              )}
            </button>

            {/* Dark / Light Toggle */}
            <button
              onClick={onToggleTheme}
              aria-label="Toggle Theme"
              className="p-2 sm:p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 hover:bg-slate-100 dark:hover:bg-slate-800 text-amber-500 dark:text-amber-400 transition-colors shadow-xs cursor-pointer"
              title={isDark ? 'Ganti ke Light Mode' : 'Ganti ke Dark Mode'}
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 lg:hidden cursor-pointer"
              aria-label="Buka Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-200 dark:border-slate-800 bg-white/98 dark:bg-slate-950/98 px-4 pt-3 pb-5 space-y-2 animate-in slide-in-from-top-2 duration-200">
          <button
            onClick={() => handleNav('home')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold ${
              currentView === 'home'
                ? 'bg-amber-500 text-slate-950 font-black'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Beranda</span>
          </button>

          <div className="text-[10px] uppercase font-black tracking-wider text-slate-400 dark:text-slate-500 px-3 pt-2">
            Pilihan Game Top Up
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {navGames.map((game) => (
              <button
                key={game.id}
                onClick={() => handleNav(game.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-colors ${
                  currentView === game.id
                    ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/40 font-black'
                    : 'text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {game.icon}
                <span className="truncate">{game.name}</span>
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              onOpenTicketFinder();
              setMobileMenuOpen(false);
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold text-amber-900 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/10 border border-amber-300 dark:border-amber-500/30 mt-3"
          >
            <div className="flex items-center gap-2.5">
              <Search className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>Lacak Status Tiket</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-200 dark:bg-amber-500/20 text-amber-900 dark:text-amber-200">
              Ticket Finder
            </span>
          </button>

          <button
            onClick={() => {
              onOpenHistory();
              setMobileMenuOpen(false);
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80 mt-2"
          >
            <div className="flex items-center gap-2.5">
              <Receipt className="w-4 h-4 text-amber-500 dark:text-cyan-400" />
              <span>Cek Riwayat Pesanan</span>
            </div>
            {orderCount > 0 && (
              <span className="px-2 py-0.5 text-[10px] font-black bg-amber-500 text-slate-950 rounded-full">
                {orderCount} Pesanan
              </span>
            )}
          </button>
        </div>
      )}
    </header>
  );
};
