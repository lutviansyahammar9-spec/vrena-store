import React, { useState } from 'react';
import { ProductItem, OrderAccountData, PaymentMethodId } from '../types';
import { PAYMENT_METHODS, formatRupiah, getGameName, formatAccountDisplay } from '../data/products';
import { ProofUpload } from './ProofUpload';
import { 
  ArrowLeft, 
  Copy, 
  Check, 
  CheckCircle2, 
  Smartphone, 
  AlertTriangle, 
  Loader2, 
  Server 
} from 'lucide-react';

interface PaymentTransferViewProps {
  methodId: PaymentMethodId;
  product: ProductItem;
  accountData: OrderAccountData;
  onConfirmPayment: (order: any) => void;
  onBack: () => void;
  onShowToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const PaymentTransferView: React.FC<PaymentTransferViewProps> = ({
  methodId,
  product,
  accountData,
  onConfirmPayment,
  onBack,
  onShowToast,
}) => {
  const [proofUrl, setProofUrl] = useState<string | null>(null);
  const [proofName, setProofName] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Persistent unique ticket number for this payment attempt (preserves on retry to prevent duplicates)
  const [ticketNumber] = useState<string>(() => 'VRN-TKT-' + Math.floor(100000 + Math.random() * 900000));

  // Server verification & Discord transmission state
  const [isVerifyingServer, setIsVerifyingServer] = useState(false);
  const [serverStepText, setServerStepText] = useState('');
  const [serverProgress, setServerProgress] = useState(0);

  const method = PAYMENT_METHODS.find((m) => m.id === methodId) || PAYMENT_METHODS[1];
  const targetNumber = method.targetNumber || '0851-1736-4018';
  const isFreeFire = product.gameId === 'freefire';

  const handleCopy = () => {
    navigator.clipboard.writeText(targetNumber.replace(/-/g, ''));
    setIsCopied(true);
    onShowToast('Nomor berhasil disalin!', 'success');
    setTimeout(() => setIsCopied(false), 2500);
  };

  const isSubmittingRef = React.useRef(false);

  const handleStartVerification = async () => {
    if (isSubmittingRef.current || isVerifyingServer) return;
    if (!proofUrl) {
      setUploadError('Silakan unggah bukti pembayaran terlebih dahulu.');
      return;
    }

    isSubmittingRef.current = true;
    setIsVerifyingServer(true);
    setSubmitError(null);
    setUploadError(null);
    setServerStepText(`Mengunggah bukti transfer ${method.name}...`);
    setServerProgress(25);

    try {
      setTimeout(() => {
        setServerStepText('Menghubungkan ke bot Discord & mengirim bukti transfer asli...');
        setServerProgress(65);
      }, 700);

      const nowWib = new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticketNumber,
          gameId: product.gameId,
          gameName: getGameName(product.gameId),
          productId: product.id,
          productName: product.name,
          productImage: product.image,
          price: product.price,
          accountData,
          paymentMethod: methodId,
          paymentMethodName: method.name,
          paymentProofDataUrl: proofUrl,
          paymentProofName: proofName || `bukti_${methodId}.jpg`,
          transferTime: `${nowWib} WIB`,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || 'Gagal mengirim bukti pembayaran ke channel Discord.');
      }

      setServerProgress(100);
      setServerStepText('Bukti pembayaran berhasil terkirim ke Discord! Membuka nota pesanan...');

      setTimeout(() => {
        onConfirmPayment(data.order);
      }, 500);
    } catch (err: any) {
      console.error('Submission to Discord failed:', err);
      isSubmittingRef.current = false;
      setIsVerifyingServer(false);
      setSubmitError(err.message || 'Terjadi gangguan saat mengirim bukti ke Discord. Silakan klik tombol Coba Lagi.');
    }
  };


  return (
    <div className="py-6 max-w-xl mx-auto px-4 sm:px-6 animate-in fade-in duration-200">
      <button
        onClick={onBack}
        disabled={isVerifyingServer}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700/80 backdrop-blur-md mb-4 transition-colors disabled:opacity-50 shadow-sm"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Ganti Metode</span>
      </button>

      {/* Main Container */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/95 shadow-xl p-5 sm:p-6">
        {/* Header with Logo */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="w-12 h-10 rounded-xl bg-white p-1.5 flex items-center justify-center shadow border border-slate-200 shrink-0">
            <img
              src={method.image}
              alt={method.name}
              className="max-h-full max-w-full object-contain"
            />
          </div>

          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
              Pembayaran {method.name}
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Transfer saldo {method.name} ke nomor akun resmi Vrena Store
            </p>
          </div>
        </div>

        {/* Compact Number Card */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-amber-100/50 dark:from-indigo-950/60 dark:to-slate-950/80 border border-amber-300 dark:border-indigo-500/40 text-center shadow-sm">
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 dark:text-indigo-300 flex items-center justify-center gap-1 mb-1">
            <Smartphone className="w-3.5 h-3.5 text-amber-600 dark:text-indigo-400" />
            <span>Nomor Tujuan Transfer {method.name}</span>
          </span>

          <div className="text-xl sm:text-2xl font-black font-mono tracking-wider text-slate-900 dark:text-white select-all">
            {targetNumber}
          </div>

          <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 font-medium">
            Atas Nama: <strong className="text-amber-800 dark:text-indigo-300">Kenos Store</strong>
          </p>

          <button
            type="button"
            onClick={handleCopy}
            className="mt-3 inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg font-bold text-xs bg-amber-500 hover:bg-amber-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white shadow transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            {isCopied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-200 stroke-[3]" />
                <span>Nomor Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Salin Nomor</span>
              </>
            )}
          </button>
        </div>

        {/* Order Details Mini-Card */}
        <div className="my-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-500 dark:text-slate-400">Produk</span>
            <span className="font-bold text-slate-900 dark:text-white">
              {getGameName(product.gameId)} — {product.name}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500 dark:text-slate-400">Akun Tujuan</span>
            <span className="font-bold text-amber-600 dark:text-indigo-400">
              {formatAccountDisplay(accountData)}
            </span>
          </div>

          <div className="pt-1.5 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
            <span className="font-bold text-slate-700 dark:text-slate-300">
              Total Pembayaran (Diskon 11.11)
            </span>
            <div className="flex items-baseline gap-2">
              {product.originalPrice && (
                <span className="text-xs text-slate-400 line-through font-semibold">
                  {formatRupiah(product.originalPrice)}
                </span>
              )}
              <span className="text-base font-black text-amber-600 dark:text-indigo-400">
                {formatRupiah(product.price)}
              </span>
            </div>
          </div>
        </div>

        {/* Upload Bukti Transfer */}
        <div className="mt-5">
          <ProofUpload
            proofUrl={proofUrl}
            proofName={proofName}
            onUpload={(url, name) => {
              setProofUrl(url);
              setProofName(name);
              setUploadError(null);
            }}
            onRemove={() => {
              setProofUrl(null);
              setProofName(null);
            }}
            onError={(msg) => setUploadError(msg)}
          />

          {uploadError && (
            <div className="mt-2.5 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/80 border border-rose-300 dark:border-rose-500/50 text-rose-700 dark:text-rose-200 text-xs flex items-center gap-2 animate-in fade-in">
              <AlertTriangle className="w-4 h-4 text-rose-500 dark:text-rose-400 shrink-0" />
              <span>{uploadError}</span>
            </div>
          )}
        </div>

        {/* Server Verification & Discord transmission Progress */}
        {isVerifyingServer && (
          <div className="mt-4 p-4 rounded-xl bg-amber-50 dark:bg-slate-950 border border-amber-300 dark:border-indigo-500/40 shadow-inner animate-in fade-in space-y-3">
            <div className="flex items-center gap-2.5 text-xs font-bold text-amber-700 dark:text-indigo-400">
              <Server className="w-4 h-4 animate-pulse shrink-0" />
              <span>{serverStepText || 'Memproses pembayaran...'}</span>
            </div>

            <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-amber-600 to-amber-400 dark:from-indigo-500 dark:via-blue-500 dark:to-cyan-400 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${serverProgress}%` }}
              />
            </div>

            <p className="text-[10px] text-slate-500 dark:text-slate-400 text-right">
              Nomor Tiket: <strong className="font-mono text-slate-700 dark:text-slate-300">{ticketNumber}</strong> ({serverProgress}%)
            </p>
          </div>
        )}

        {/* Discord Transmission Error & Retry Option */}
        {submitError && !isVerifyingServer && (
          <div className="mt-4 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/80 border border-rose-300 dark:border-rose-500/50 text-rose-700 dark:text-rose-200 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-2.5 text-xs font-semibold">
              <AlertTriangle className="w-4 h-4 text-rose-500 dark:text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-rose-800 dark:text-rose-300">Gagal Mengirim Bukti Pembayaran ke Discord</p>
                <p className="text-[11px] mt-0.5 text-rose-600 dark:text-rose-300/90">{submitError}</p>
                <p className="text-[10px] mt-1 text-slate-500 dark:text-slate-400">
                  Nomor tiket <strong className="font-mono">{ticketNumber}</strong> tetap disimpan dan tidak akan membuat pesanan duplikat saat dicoba lagi.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleStartVerification}
              className="w-full py-2.5 px-4 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Coba Lagi Kirim Bukti Transfer</span>
            </button>
          </div>
        )}

        {/* Submit Button */}
        <div className="mt-5">
          <button
            onClick={handleStartVerification}
            disabled={!proofUrl || isVerifyingServer}
            className={`w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg cursor-pointer ${
              proofUrl && !isVerifyingServer
                ? 'bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-600 hover:to-amber-700 dark:from-indigo-600 dark:via-blue-600 dark:to-cyan-500 text-white shadow-amber-500/20 dark:shadow-indigo-600/25 hover:scale-[1.01] active:scale-[0.99]'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed border border-slate-200 dark:border-slate-700/50 shadow-none'
            }`}
          >
            {isVerifyingServer ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Mengirim ke Bot Discord...</span>
              </>
            ) : submitError ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Coba Kirim Ulang Bukti</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Lanjutkan Pembayaran</span>
              </>
            )}
          </button>
          {!proofUrl && !isVerifyingServer && (
            <p className="text-center text-[11px] text-amber-600 dark:text-rose-400 mt-1.5 font-medium">
              Silakan unggah bukti pembayaran terlebih dahulu.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
