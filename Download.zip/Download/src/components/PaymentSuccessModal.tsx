import React, { useState } from 'react';
import { OrderRecord } from '../types';
import { formatRupiah, formatAccountDisplay } from '../data/products';
import { Check, Clock, Home, History, Sparkles, Image as ImageIcon, Copy } from 'lucide-react';

interface PaymentSuccessModalProps {
  order: OrderRecord;
  onBackToHome: () => void;
  onOpenHistory: () => void;
}

export const PaymentSuccessModal: React.FC<PaymentSuccessModalProps> = ({
  order,
  onBackToHome,
  onOpenHistory,
}) => {
  const [copied, setCopied] = useState(false);
  const isFreeFire = order.gameId === 'freefire';

  const handleCopy = () => {
    const text = order.ticketNumber || order.orderId;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-300">
      <div className="relative w-full max-w-xl my-8 rounded-3xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-900/95 shadow-2xl p-6 sm:p-8 text-center animate-in zoom-in-95 duration-300">
        {/* Glow ambient background */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/10 dark:bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Animated Success Checkmark */}
        <div className="relative mx-auto mb-5 w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-500/20 border-2 border-emerald-400 dark:border-emerald-500/50 flex items-center justify-center shadow-lg shadow-emerald-500/10 dark:shadow-emerald-500/25">
          <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 dark:from-emerald-600 dark:to-teal-400 flex items-center justify-center shadow-inner">
            <Check className="w-8 h-8 text-white stroke-[3] animate-in zoom-in-75 duration-300" />
          </div>
          <span className="absolute -bottom-1 -right-1 p-1 rounded-full bg-amber-400 dark:bg-emerald-400 text-slate-950">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </span>
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
          Pembayaran Berhasil!
        </h2>

        {/* Game delivery notice */}
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 font-medium">
          Pesanan sedang diproses dan item akan langsung masuk ke akun kamu (estimasi 1x24 jam).
        </p>

        {/* Order Status Badge */}
        <div className={`mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold border ${
          order.status === 'Pembayaran Berhasil'
            ? 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-300 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-400'
            : order.status === 'Pembayaran Ditolak'
            ? 'bg-rose-50 dark:bg-rose-500/15 border-rose-300 dark:border-rose-500/30 text-rose-700 dark:text-rose-400'
            : 'bg-amber-50 dark:bg-amber-500/15 border-amber-300 dark:border-amber-500/30 text-amber-700 dark:text-amber-400'
        }`}>
          <Clock className="w-4 h-4" />
          <span>Status: {order.status}</span>
        </div>

        {/* Order Summary Receipt Box */}
        <div className="mt-6 p-5 rounded-2xl bg-slate-50 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800 text-left space-y-3 text-xs sm:text-sm shadow-sm">
          <div className="flex justify-between items-center pb-2.5 border-b border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Nomor Ticket</span>
            <div className="flex items-center gap-1.5">
              <span className="font-mono font-bold text-amber-800 dark:text-indigo-300 bg-amber-100 dark:bg-indigo-950/60 px-2.5 py-1 rounded-md border border-amber-300 dark:border-indigo-800/60 select-all">
                {order.ticketNumber || order.orderId}
              </span>
              <button
                type="button"
                onClick={handleCopy}
                title="Salin Nomor Tiket"
                className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-emerald-600 dark:text-emerald-400">Tersalin</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-amber-600 dark:text-indigo-400" />
                    <span>Salin</span>
                  </>
                )}
              </button>
            </div>
          </div>


          <div className="flex justify-between items-center">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Nama Game</span>
            <span className="font-bold text-slate-900 dark:text-white">
              {order.gameName}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Produk</span>
            <span className="font-bold text-amber-600 dark:text-indigo-400">
              {order.productName}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Akun Tujuan</span>
            <span className="font-bold text-slate-900 dark:text-white">
              {formatAccountDisplay(order.accountData)}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Metode Pembayaran</span>
            <span className="font-bold text-slate-900 dark:text-white">
              {order.paymentMethodName}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Waktu Transaksi</span>
            <span className="text-slate-600 dark:text-slate-300">
              {order.createdAt}
            </span>
          </div>

          <div className="pt-2.5 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-base">
            <span className="font-bold text-slate-800 dark:text-slate-200">
              Total Pembayaran
            </span>
            <span className="font-black text-amber-600 dark:text-emerald-400 text-lg">
              {formatRupiah(order.price)}
            </span>
          </div>

          {/* Proof thumbnail preview */}
          {order.paymentProofUrl && (
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-amber-600 dark:text-indigo-400" />
                Bukti Transfer:
              </span>
              <div className="w-14 h-14 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 shrink-0">
                <img
                  src={order.paymentProofUrl}
                  alt="Bukti Transfer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <button
            onClick={onBackToHome}
            className="flex-1 py-3.5 px-5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-600 hover:to-amber-700 dark:from-indigo-600 dark:to-blue-600 dark:hover:from-indigo-500 dark:hover:to-blue-500 text-white shadow-lg shadow-amber-500/20 dark:shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Kembali ke Halaman Utama</span>
          </button>

          <button
            onClick={onOpenHistory}
            className="py-3.5 px-5 rounded-xl font-bold text-sm bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <History className="w-4 h-4 text-amber-600 dark:text-cyan-400" />
            <span>Lihat Riwayat</span>
          </button>
        </div>
      </div>
    </div>
  );
};
