import React from 'react';
import { ProductItem } from '../types';
import {
  STORE_ASSETS,
  POKEMON_UNITE_PRODUCTS,
  formatRupiah,
  getDiscountPercentage,
} from '../data/products';
import { TopBackButton } from './TopBackButton';
import { Promo1111Banner } from './Promo1111Banner';
import { Check, ShieldCheck, Gem, Flame } from 'lucide-react';

interface PokemonUniteViewProps {
  selectedProduct: ProductItem | null;
  onSelectProduct: (product: ProductItem) => void;
  onBackToHome: () => void;
}

export const PokemonUniteView: React.FC<PokemonUniteViewProps> = ({
  selectedProduct,
  onSelectProduct,
  onBackToHome,
}) => {
  return (
    <div className="pb-36 pt-3 max-w-4xl mx-auto px-4 sm:px-6">
      {/* Prominent Top Back Bar */}
      <TopBackButton onBack={onBackToHome} gameName="Pokemon Unite" />

      {/* 11.11 Mega Sale Banner */}
      <Promo1111Banner gameName="Pokemon Unite" />

      {/* Top Banner & Header (2.4:1 Aspect Ratio) */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-md mb-6">
        <div className="relative aspect-[1942/809] w-full overflow-hidden bg-slate-100 dark:bg-slate-950">
          <img
            src={STORE_ASSETS.pokemonuniteBanner}
            alt="Pokemon Unite Banner"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-4 sm:p-5 relative z-10 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-slate-950 dark:text-white tracking-tight">
                  Pokemon Unite Top Up
                </h1>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-sm">
                  <Flame className="w-3 h-3 fill-amber-200 mr-0.5" />
                  11.11 DISKON SPESIAL
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 dark:bg-purple-500/15 text-amber-700 dark:text-purple-400 border border-amber-500/30 dark:border-purple-500/30">
                  <ShieldCheck className="w-3 h-3 mr-1" />
                  Resmi & Legal
                </span>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-slate-950 dark:text-slate-300 mt-1 leading-relaxed">
                Top up Aeos Gems Pokemon Unite resmi dan instan dengan promo 11.11 termurah di Vrena Store. Cukup masukkan 7 digit Trainer ID.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Title */}
      <div className="flex items-center gap-2 mb-4">
        <div className="w-6 h-6 rounded-lg bg-amber-500 dark:bg-purple-600 text-white font-black text-xs flex items-center justify-center shadow-sm">
          1
        </div>
        <h2 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">
          Pilih Nominal Aeos Gems
        </h2>
      </div>

      {/* Grid of AeosGems */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2.5">
          <Gem className="w-4 h-4 text-amber-500 dark:text-purple-400" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-white">
            AeosGems (ID)
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {POKEMON_UNITE_PRODUCTS.map((product) => {
            const isSelected = selectedProduct?.id === product.id;
            const discount = getDiscountPercentage(product.price, product.originalPrice);

            return (
              <div
                key={product.id}
                onClick={() => onSelectProduct(product)}
                className={`relative cursor-pointer rounded-2xl p-3.5 border transition-all duration-200 flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-500 dark:border-purple-500 bg-amber-50/70 dark:bg-purple-500/15 ring-2 ring-amber-400 dark:ring-purple-500/80 shadow-lg shadow-amber-500/10 dark:shadow-purple-500/20'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 hover:border-amber-300 dark:hover:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/80 shadow-sm'
                }`}
              >
                {discount && (
                  <div className="absolute top-2 right-2">
                    <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-red-600 text-white shadow-sm">
                      -{discount}%
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-2.5 mb-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-950 p-1 flex items-center justify-center border border-slate-200 dark:border-slate-800 shrink-0">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain filter drop-shadow"
                    />
                  </div>
                  <h4 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white leading-tight">
                    {product.name}
                  </h4>
                </div>

                <div className="pt-2 border-t border-slate-150 dark:border-slate-800/80 flex items-end justify-between font-mono">
                  <div>
                    <div className="text-xs sm:text-sm font-black text-amber-600 dark:text-purple-400">
                      {formatRupiah(product.price)}
                    </div>
                    {product.originalPrice && (
                      <div className="text-[10px] sm:text-[11px] text-slate-400 line-through font-semibold">
                        {formatRupiah(product.originalPrice)}
                      </div>
                    )}
                  </div>

                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-amber-500 dark:bg-purple-600 text-white flex items-center justify-center shadow">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
