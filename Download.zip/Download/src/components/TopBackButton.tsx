import React from 'react';
import { ArrowLeft, CheckCircle2, ShieldCheck } from 'lucide-react';

interface TopBackButtonProps {
  onBack: () => void;
  gameName: string;
  badgeText?: string;
}

export const TopBackButton: React.FC<TopBackButtonProps> = ({
  onBack,
  gameName,
  badgeText = 'Proses Otomatis 1-3 Menit',
}) => {
  return (
    <div className="sticky top-16 z-30 mb-4 py-2 px-3 sm:px-4 rounded-2xl bg-white/95 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-md flex items-center justify-between gap-3 transition-colors">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-black bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer shrink-0"
        aria-label="Kembali ke Pilihan Game"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali ke Beranda</span>
      </button>

      <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 overflow-hidden text-ellipsis whitespace-nowrap">
        <span className="hidden md:inline text-slate-400 dark:text-slate-500">Vrena Store</span>
        <span className="hidden md:inline text-slate-300 dark:text-slate-600">/</span>
        <span className="text-slate-900 dark:text-white font-extrabold truncate">
          {gameName}
        </span>
        <span className="hidden sm:inline-flex items-center gap-1 ml-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/25">
          <CheckCircle2 className="w-3 h-3" />
          <span>{badgeText}</span>
        </span>
      </div>
    </div>
  );
};
