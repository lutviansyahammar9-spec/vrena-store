import React, { useState } from 'react';
import { OrderRecord } from '../types';
import { formatRupiah, formatAccountDisplay } from '../data/products';
import { 
  Search, 
  X, 
  Copy, 
  Check, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Loader2, 
  ExternalLink, 
  Image as ImageIcon,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

interface TicketFinderModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentOrders?: OrderRecord[];
}

export const TicketFinderModal: React.FC<TicketFinderModalProps> = ({
  isOpen,
  onClose,
  recentOrders = [],
}) => {
  const [ticketInput, setTicketInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchedOrder, setSearchedOrder] = useState<OrderRecord | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [copied, setCopied] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const executeSearch = async (ticketToSearch: string) => {
    const trimmed = ticketToSearch.trim();
    if (!trimmed) return;

    setIsLoading(true);
    setNotFound(false);
    setSearchError(null);
    setSearchedOrder(null);

    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(trimmed)}`);
      if (res.status === 404) {
        setNotFound(true);
        setIsLoading(false);
        return;
      }
      const data = await res.json();
      if (data && data.success && data.order) {
        setSearchedOrder(data.order);
      } else {
        setNotFound(true);
      }
    } catch (err: any) {
      console.error('Ticket search error:', err);
      setSearchError('Gagal menghubungkan ke server pencarian tiket. Silakan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(ticketInput);
  };

  const handleQuickSelect = (ticket: string) => {
    setTicketInput(ticket);
    executeSearch(ticket);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl border border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-900/95 shadow-2xl animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-indigo-500/15 text-amber-600 dark:text-indigo-400 flex items-center justify-center">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                Ticket Finder - Lacak Pesanan
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Cek status verifikasi, catatan admin, dan detail pesanan secara real-time
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Search Form */}
          <form onSubmit={handleSearchSubmit} className="space-y-3">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              Masukkan Nomor Tiket Transaksi:
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={ticketInput}
                  onChange={(e) => setTicketInput(e.target.value)}
                  placeholder="Contoh: VRN-TKT-123456"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 dark:focus:ring-indigo-500 shadow-inner"
                />
                {ticketInput && (
                  <button
                    type="button"
                    onClick={() => setTicketInput('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <button
                type="submit"
                disabled={isLoading || !ticketInput.trim()}
                className="px-5 py-3 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white shadow transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Mencari...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Cari Tiket</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick-select pills from recent orders */}
            {recentOrders.length > 0 && !searchedOrder && (
              <div className="pt-2">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1.5">
                  Tiket Pesanan Terakhir Kamu:
                </span>
                <div className="flex flex-wrap gap-2">
                  {recentOrders.slice(0, 4).map((ord) => {
                    const ticket = ord.ticketNumber || ord.orderId;
                    return (
                      <button
                        key={ticket}
                        type="button"
                        onClick={() => handleQuickSelect(ticket)}
                        className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 hover:bg-amber-100 dark:hover:bg-indigo-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                      >
                        {ticket}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </form>

          {/* Search Error */}
          {searchError && (
            <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/80 border border-rose-300 dark:border-rose-500/40 text-rose-700 dark:text-rose-200 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{searchError}</span>
            </div>
          )}

          {/* Not Found state */}
          {notFound && !isLoading && (
            <div className="py-8 text-center bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200 dark:border-slate-800 p-6">
              <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-500 flex items-center justify-center mx-auto mb-2.5">
                <XCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Tiket Tidak Ditemukan
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                Nomor tiket &ldquo;{ticketInput}&rdquo; tidak terdaftar di sistem. Pastikan kamu memasukkan nomor tiket yang benar.
              </p>
            </div>
          )}

          {/* Search Result Card */}
          {searchedOrder && !isLoading && (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70 p-5 space-y-4 shadow-sm animate-in fade-in duration-200">
              {/* Ticket and Status Banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block">Nomor Tiket:</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="font-mono text-sm sm:text-base font-black text-amber-700 dark:text-indigo-400 bg-amber-100 dark:bg-indigo-950/80 px-2.5 py-1 rounded-md border border-amber-300 dark:border-indigo-800/80 select-all">
                      {searchedOrder.ticketNumber || searchedOrder.orderId}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(searchedOrder.ticketNumber || searchedOrder.orderId)}
                      title="Salin Nomor Tiket"
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-emerald-600 dark:text-emerald-400">Tersalin</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-amber-600 dark:text-indigo-400" />
                          <span>Salin</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">Status Verifikasi:</span>
                  {searchedOrder.status === 'Pembayaran Berhasil' ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-500/30">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Pembayaran Berhasil</span>
                    </span>
                  ) : searchedOrder.status === 'Pembayaran Ditolak' ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-400 border border-rose-300 dark:border-rose-500/30">
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Pembayaran Ditolak</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-500/30">
                      <Clock className="w-3.5 h-3.5 animate-pulse" />
                      <span>Menunggu Proses Pesanan</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Status Explanation Box */}
              {searchedOrder.status === 'Pembayaran Berhasil' && (
                <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-500/40 text-emerald-800 dark:text-emerald-200 text-xs space-y-1">
                  <p className="font-bold">Pembayaran Disetujui</p>
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-300/90 leading-relaxed">
                    Diverifikasi oleh: <strong>VrenaStore</strong>. Pesanan kamu telah berhasil diproses dan item game sudah dikirimkan ke akun tujuan.
                  </p>
                </div>
              )}

              {searchedOrder.status === 'Pembayaran Ditolak' && (
                <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/70 border border-rose-300 dark:border-rose-500/40 text-rose-900 dark:text-rose-100 text-xs space-y-2.5 shadow-sm">
                  <div className="flex items-center gap-1.5 font-bold text-rose-700 dark:text-rose-400">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>Catatan Alasan Penolakan dari Admin:</span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 font-medium text-slate-800 dark:text-slate-200 text-xs leading-relaxed">
                    &ldquo;{searchedOrder.rejectReason || 'Pembayaran tidak memenuhi ketentuan verifikasi.'}&rdquo;
                  </div>

                  <div className="pt-1 border-t border-rose-200/80 dark:border-rose-900/60 flex flex-col gap-1 text-[11px]">
                    <span className="font-bold text-rose-800 dark:text-rose-300">
                      Catatan Pengembalian: Dana akan dikembalikan sesuai nominal.
                    </span>
                    <span className="text-slate-500 dark:text-slate-400">
                      Diverifikasi oleh: <strong>VrenaStore</strong>
                    </span>
                  </div>
                </div>
              )}

              {searchedOrder.status === 'Menunggu Proses Pesanan' && (
                <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-500/40 text-amber-800 dark:text-amber-200 text-xs space-y-1">
                  <p className="font-bold">Sedang Dalam Antrean Verifikasi</p>
                  <p className="text-[11px] text-amber-700 dark:text-amber-300/90 leading-relaxed">
                    Bukti pembayaran kamu telah terkirim ke sistem VrenaStore. Admin sedang melakukan pengecekan mutasi transfer.
                  </p>
                </div>
              )}

              {/* Order Specifics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Game:</span>
                  <strong className="text-slate-900 dark:text-white font-bold">{searchedOrder.gameName}</strong>
                </div>

                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Produk:</span>
                  <strong className="text-slate-900 dark:text-white font-bold">{searchedOrder.productName}</strong>
                </div>

                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Akun Tujuan:</span>
                  <strong className="text-amber-600 dark:text-indigo-400 font-bold">{formatAccountDisplay(searchedOrder.accountData)}</strong>
                </div>

                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Metode Pembayaran:</span>
                  <strong className="text-slate-900 dark:text-white font-bold">{searchedOrder.paymentMethodName}</strong>
                </div>

                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Total Nominal:</span>
                  <strong className="text-base font-black text-amber-600 dark:text-emerald-400">{formatRupiah(searchedOrder.price)}</strong>
                </div>

                <div>
                  <span className="text-slate-500 dark:text-slate-400 block">Waktu Transaksi:</span>
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{searchedOrder.createdAt}</span>
                </div>
              </div>

              {/* Proof Image */}
              {searchedOrder.paymentProofUrl && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-amber-600 dark:text-indigo-400" />
                    <span>Bukti Transfer:</span>
                  </span>

                  <a
                    href={searchedOrder.paymentProofUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600 dark:text-indigo-400 hover:underline"
                  >
                    <span>Lihat Gambar Struk</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          {searchedOrder && (
            <button
              type="button"
              onClick={() => executeSearch(searchedOrder.ticketNumber || searchedOrder.orderId)}
              disabled={isLoading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Segarkan Status</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="ml-auto px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white shadow transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
