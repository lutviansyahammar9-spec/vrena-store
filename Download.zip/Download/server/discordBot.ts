import {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  TextChannel,
  PermissionFlagsBits,
  ButtonInteraction,
  ModalSubmitInteraction,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
} from 'discord.js';
import fs from 'fs';
import path from 'path';
import {
  StoredOrder,
  OrderStatus,
  getOrderByTicket,
  updateOrderStatus,
} from './ordersDb.js';

let discordClient: Client | null = null;
let isBotReady = false;

// Fallback token provided by user
const FALLBACK_DISCORD_TOKEN = 'MTU2ODUyNzgzODM4NTAyMDk2OA.GeZQGo.FuGpb3RPr8QUL5U3g95P1yN_pZGCT4-FCZpb10';
const DEFAULT_CHANNEL_ID = '1568530505287335976';

export function initDiscordBot(): Client {
  if (discordClient) return discordClient;

  const token = process.env.DISCORD_TOKEN || FALLBACK_DISCORD_TOKEN;
  if (!token) {
    console.warn('[Discord Bot] DISCORD_TOKEN tidak ditemukan.');
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
    ],
  });

  client.once('ready', () => {
    isBotReady = true;
    console.log(`[Discord Bot] Terhubung sebagai ${client.user?.tag}`);
  });

  client.on('error', (err) => {
    console.error('[Discord Bot] Error:', err);
  });

  client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
      await handleButtonInteraction(interaction);
    } else if (interaction.isModalSubmit()) {
      await handleModalSubmit(interaction);
    }
  });

  if (token) {
    client.login(token).catch((err) => {
      console.error('[Discord Bot] Gagal login ke Discord:', err?.message || err);
    });
  }

  discordClient = client;
  return client;
}

export function isDiscordReady(): boolean {
  return isBotReady && discordClient !== null && discordClient.isReady();
}

/**
 * Format game-specific account lines according to the game:
 * - Roblox: USERNAME ROBLOX
 * - Mobile Legends: NICKNAME, USER ID, ZONE ID / SERVER ID
 * - Free Fire: NICKNAME, UID FREE FIRE
 * - FC Mobile: NICKNAME, UID FC MOBILE
 * - Pokemon Unite: NICKNAME, TRAINER ID
 * - Blood Strike: NICKNAME, USER ID BLOOD STRIKE
 */
export function formatAccountDetails(order: StoredOrder): string {
  const gId = (order.gameId || '').toLowerCase();
  const acc = order.accountData || {};

  if (gId === 'roblox') {
    const username = acc.username || acc.uid || '-';
    return `> **USERNAME ROBLOX:** ${username}`;
  }

  if (gId === 'mobilelegend') {
    const nickname = acc.nickname ? `> **NICKNAME:** ${acc.nickname}\n` : '';
    const uid = acc.uid || '-';
    const serverId = acc.serverId || '-';
    return `${nickname}> **USER ID:** ${uid}\n> **ZONE ID / SERVER ID:** ${serverId}`;
  }

  if (gId === 'freefire') {
    const nickname = acc.nickname || '-';
    const uid = acc.uid || '-';
    return `> **NICKNAME:** ${nickname}\n> **UID FREE FIRE:** ${uid}`;
  }

  if (gId === 'fcmobile') {
    const nickname = acc.nickname ? `> **NICKNAME:** ${acc.nickname}\n` : '';
    const uid = acc.uid || '-';
    return `${nickname}> **UID FC MOBILE:** ${uid}`;
  }

  if (gId === 'pokemonunite') {
    const nickname = acc.nickname ? `> **NICKNAME:** ${acc.nickname}\n` : '';
    const uid = acc.uid || '-';
    return `${nickname}> **TRAINER ID:** ${uid}`;
  }

  if (gId === 'bloodstrike') {
    const nickname = acc.nickname ? `> **NICKNAME:** ${acc.nickname}\n` : '';
    const uid = acc.uid || '-';
    return `${nickname}> **USER ID BLOOD STRIKE:** ${uid}`;
  }

  // Generic fallback
  const nickname = acc.nickname ? `> **NICKNAME:** ${acc.nickname}\n` : '';
  const uid = acc.uid || acc.username || '-';
  return `${nickname}> **USER ID:** ${uid}`;
}

/**
 * Resolve local product image buffer to attach as sticker thumbnail
 */
export function resolveProductImage(order: StoredOrder): { buffer: Buffer; fileName: string } | null {
  const gId = (order.gameId || '').toLowerCase();
  const pId = (order.productId || '').toLowerCase();
  const pName = (order.productName || '').toLowerCase();

  const candidates: string[] = [];

  // If productImage dataUrl or path was supplied
  if (order.productImage) {
    if (order.productImage.startsWith('data:image')) {
      const match = order.productImage.match(/^data:image\/([a-zA-Z0-9]+);base64,(.+)$/);
      if (match) {
        const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
        return {
          buffer: Buffer.from(match[2], 'base64'),
          fileName: `product_sticker.${ext}`,
        };
      }
    } else {
      candidates.push(order.productImage.replace(/^\//, ''));
      candidates.push(path.join('public', order.productImage.replace(/^\//, '')));
    }
  }

  // Free Fire products
  if (gId === 'freefire') {
    if (pId.includes('bp') || pName.includes('bp') || pName.includes('pass')) {
      candidates.push('public/images/freefire/bp_card.webp');
    } else if (pId.includes('mingguan') || pName.includes('mingguan')) {
      candidates.push('public/images/freefire/member_mingguan.png');
    } else if (pId.includes('bulanan') || pName.includes('bulanan')) {
      candidates.push('public/images/freefire/member_bulanan.png');
    } else if (pId.includes('throne') || pName.includes('throne')) {
      candidates.push('public/images/freefire/ffws_throne.png');
    } else if (pId.includes('permaisuri') || pName.includes('permaisuri')) {
      candidates.push('public/images/freefire/permaisuri_cahaya_bundle.png');
    } else if (pId.includes('scar') || pName.includes('scar')) {
      candidates.push('public/images/freefire/scar_cahaya_bulan.png');
    } else if (pId.includes('sultan') || pName.includes('sultan')) {
      candidates.push('public/images/freefire/sultan_cahaya_bundle.png');
    } else if (pId.includes('supergamer') || pName.includes('supergamer')) {
      candidates.push('public/images/freefire/supergamer_bundle.png');
    } else {
      candidates.push('public/images/freefire/diamond_freefire.png');
    }
  } else if (gId === 'roblox') {
    candidates.push('public/images/roblox/robux.jpg');
  } else if (gId === 'mobilelegend') {
    if (pId.includes('pass') || pName.includes('pass')) {
      candidates.push('public/images/mobilelegend/weekly_pass.png');
    } else {
      candidates.push('public/images/mobilelegend/diamond_mlbb.png');
    }
  } else if (gId === 'fcmobile') {
    if (pId.includes('silver') || pName.includes('silver')) {
      candidates.push('public/images/fcmobile/silver.png');
    } else {
      candidates.push('public/images/fcmobile/fc_point.png');
    }
  } else if (gId === 'pokemonunite') {
    candidates.push('public/images/pokemonunite/aeos_gems.png');
  } else if (gId === 'bloodstrike') {
    candidates.push('public/images/bloodstrike/gold.png');
  }

  for (const c of candidates) {
    const full = path.resolve(process.cwd(), c);
    if (fs.existsSync(full)) {
      try {
        const ext = path.extname(full).replace('.', '') || 'png';
        const buffer = fs.readFileSync(full);
        return { buffer, fileName: `product_sticker.${ext}` };
      } catch (err) {
        console.warn('Failed reading product image candidate:', full, err);
      }
    }
  }

  return null;
}

/**
 * Build rich styled Embed bubble with typographic hierarchy (large, small, bold, code block)
 * Absolutely NO emojis.
 */
export function buildOrderEmbed(
  order: StoredOrder,
  proofAttachmentName: string,
  stickerAttachmentName?: string
): EmbedBuilder {
  const accountLines = formatAccountDetails(order);

  const embed = new EmbedBuilder()
    .setColor(0xF59E0B) // Amber Gold bubble theme
    .setAuthor({
      name: `VRENA STORE - SISTEM PEMBAYARAN (${(order.gameName || 'TOP UP').toUpperCase()})`,
    })
    .setTitle('PESANAN TOP UP BARU')
    .setDescription(
      `# PESANAN TOP UP BARU\n` +
      `-# Silakan verifikasi kesesuaian struk transfer dengan nominal di bawah\n\n` +
      `### NOMOR TICKET\n` +
      `\`\`\`\n${order.ticketNumber}\n\`\`\`\n` +
      `${accountLines}\n` +
      `> **GAME:** ${order.gameName || 'Game'}\n` +
      `> **PRODUK:** ${order.productName}\n` +
      `> **METODE PEMBAYARAN:** ${order.paymentMethodName || 'QRIS'}\n` +
      `> **NOMINAL PEMBAYARAN:** ${order.nominalFormatted}\n` +
      `> **WAKTU TRANSFER:** ${order.transferTime}\n` +
      `> **BUKTI TRANSFER:** Gambar struk pembayaran terlampir di bawah`
    )
    .setImage(`attachment://${proofAttachmentName}`)
    .setFooter({
      text: `Vrena Store • Nomor Tiket: ${order.ticketNumber}`,
    })
    .setTimestamp();

  if (stickerAttachmentName) {
    embed.setThumbnail(`attachment://${stickerAttachmentName}`);
  }

  return embed;
}

/**
 * Send order notification with styled embed bubble, product sticker thumbnail, and original proof image.
 * Strictly sends 1 message per order.
 */
export async function sendOrderToDiscord(
  order: StoredOrder,
  imageBuffer: Buffer,
  fileName: string
): Promise<{ messageId: string; channelId: string }> {
  const token = process.env.DISCORD_TOKEN || FALLBACK_DISCORD_TOKEN;
  const channelId = process.env.DISCORD_CHANNEL_ID || DEFAULT_CHANNEL_ID;

  if (!token) {
    throw new Error('Konfigurasi DISCORD_TOKEN belum diatur.');
  }

  if (!discordClient || !discordClient.isReady()) {
    let waited = 0;
    while ((!discordClient || !discordClient.isReady()) && waited < 5000) {
      await new Promise((resolve) => setTimeout(resolve, 300));
      waited += 300;
    }
    if (!discordClient || !discordClient.isReady()) {
      throw new Error('Bot Discord belum terhubung. Silakan coba sesaat lagi.');
    }
  }

  const channel = await discordClient.channels.fetch(channelId);
  if (!channel || !(channel instanceof TextChannel)) {
    throw new Error(`Channel Discord dengan ID ${channelId} tidak ditemukan atau bukan text channel.`);
  }

  const cleanFileName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_') || 'bukti_transfer.jpg';
  const proofAttachment = new AttachmentBuilder(imageBuffer, { name: cleanFileName });

  const files: AttachmentBuilder[] = [proofAttachment];

  // Sticker image corresponding to the ordered item
  let stickerName: string | undefined;
  const productSticker = resolveProductImage(order);
  if (productSticker) {
    stickerName = productSticker.fileName;
    files.push(new AttachmentBuilder(productSticker.buffer, { name: stickerName }));
  }

  const embed = buildOrderEmbed(order, cleanFileName, stickerName);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`approve_${order.ticketNumber}`)
      .setLabel('SELESAIKAN PEMBAYARAN')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`reject_${order.ticketNumber}`)
      .setLabel('TOLAK PEMBAYARAN')
      .setStyle(ButtonStyle.Danger)
  );

  const sentMessage = await channel.send({
    embeds: [embed],
    files: files,
    components: [row],
  });

  return {
    messageId: sentMessage.id,
    channelId: sentMessage.channelId,
  };
}

/**
 * Verify admin authorization
 */
function isUserAdmin(interaction: ButtonInteraction | ModalSubmitInteraction): boolean {
  const memberPerms = interaction.memberPermissions;
  const isServerOwner = interaction.guild?.ownerId === interaction.user.id;

  return Boolean(
    isServerOwner ||
    (memberPerms && (
      memberPerms.has(PermissionFlagsBits.Administrator) ||
      memberPerms.has(PermissionFlagsBits.ManageGuild) ||
      memberPerms.has(PermissionFlagsBits.ManageMessages) ||
      memberPerms.has(PermissionFlagsBits.ModerateMembers) ||
      memberPerms.has(PermissionFlagsBits.ManageChannels)
    ))
  );
}

/**
 * Handle button clicks from authorized Discord admins
 */
async function handleButtonInteraction(interaction: ButtonInteraction) {
  const customId = interaction.customId;
  const isApprove = customId.startsWith('approve_');
  const isReject = customId.startsWith('reject_');

  if (!isApprove && !isReject) return;

  const ticketNumber = customId.replace(/^(approve|reject)_/, '');

  // 1. Authorization check
  if (!isUserAdmin(interaction)) {
    await interaction.reply({
      content: 'Akses ditolak: Hanya admin Discord yang berwenang yang boleh menggunakan tombol verifikasi pembayaran.',
      ephemeral: true,
    });
    return;
  }

  // 2. Fetch order
  const order = getOrderByTicket(ticketNumber);
  if (!order) {
    await interaction.reply({
      content: `Pesanan dengan Nomor Ticket ${ticketNumber} tidak ditemukan di database.`,
      ephemeral: true,
    });
    return;
  }

  // 3. Double-processing prevention check
  if (order.status !== 'Menunggu Proses Pesanan') {
    await interaction.reply({
      content: `Pesanan dengan Nomor Ticket ${ticketNumber} sudah pernah diproses sebelumnya. Status saat ini: ${order.status}.`,
      ephemeral: true,
    });
    return;
  }

  // 4. If REJECT: Show Modal to request rejection reason from admin
  if (isReject) {
    const modal = new ModalBuilder()
      .setCustomId(`modal_reject_${ticketNumber}`)
      .setTitle('Alasan Penolakan Pembayaran');

    const reasonInput = new TextInputBuilder()
      .setCustomId('reject_reason')
      .setLabel('Alasan Pembayaran Ditolak')
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('Contoh: Nominal transfer kurang, bukti struk buram/tidak valid, dll.')
      .setRequired(true)
      .setMinLength(3)
      .setMaxLength(500);

    const modalRow = new ActionRowBuilder<TextInputBuilder>().addComponents(reasonInput);
    modal.addComponents(modalRow);

    await interaction.showModal(modal);
    return;
  }

  // 5. If APPROVE: Update database and Discord message immediately
  const updatedOrder = updateOrderStatus(ticketNumber, 'Pembayaran Berhasil', 'VrenaStore');
  if (!updatedOrder) {
    await interaction.reply({
      content: `Gagal memperbarui status pesanan ${ticketNumber} di database.`,
      ephemeral: true,
    });
    return;
  }

  const disabledRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`done_approve_${ticketNumber}`)
      .setLabel('SELESAIKAN PEMBAYARAN')
      .setStyle(ButtonStyle.Success)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`done_reject_${ticketNumber}`)
      .setLabel('TOLAK PEMBAYARAN')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(true)
  );

  const nowWib = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const accountLines = formatAccountDetails(order);

  // Build updated embed without re-assigning .setImage so it never duplicates image
  const originalEmbed = interaction.message.embeds[0];
  const updatedEmbed = (originalEmbed ? EmbedBuilder.from(originalEmbed) : new EmbedBuilder())
    .setColor(0x10B981) // Emerald Green
    .setAuthor({
      name: `VRENA STORE - PEMBAYARAN DISETUJUI (${(order.gameName || 'TOP UP').toUpperCase()})`,
    })
    .setTitle('PESANAN TOP UP - PEMBAYARAN BERHASIL')
    .setDescription(
      `# PEMBAYARAN BERHASIL\n` +
      `-# Pesanan telah diverifikasi dan disetujui\n\n` +
      `### NOMOR TICKET\n` +
      `\`\`\`\n${order.ticketNumber}\n\`\`\`\n` +
      `${accountLines}\n` +
      `> **GAME:** ${order.gameName || 'Game'}\n` +
      `> **PRODUK:** ${order.productName}\n` +
      `> **METODE PEMBAYARAN:** ${order.paymentMethodName || 'QRIS'}\n` +
      `> **NOMINAL PEMBAYARAN:** ${order.nominalFormatted}\n` +
      `> **WAKTU TRANSFER:** ${order.transferTime}\n\n` +
      `**STATUS PESANAN:** PEMBAYARAN BERHASIL\n` +
      `**DIVERIFIKASI OLEH:** Diverifikasi oleh VrenaStore\n` +
      `**WAKTU VERIFIKASI:** ${nowWib} WIB`
    )
    .setFooter({
      text: `Status: Pembayaran Berhasil • Diverifikasi oleh VrenaStore`,
    })
    .setTimestamp();

  try {
    await interaction.update({
      embeds: [updatedEmbed],
      components: [disabledRow],
    });

    await interaction.followUp({
      content: `Berhasil: Status pesanan ${ticketNumber} telah diubah menjadi "Pembayaran Berhasil" (Diverifikasi oleh VrenaStore).`,
      ephemeral: true,
    });
  } catch (err: any) {
    console.error('[Discord Bot] Gagal mengupdate embed status approve:', err);
  }
}

/**
 * Handle Rejection Modal Submit from Discord admin
 */
async function handleModalSubmit(interaction: ModalSubmitInteraction) {
  const customId = interaction.customId;
  if (!customId.startsWith('modal_reject_')) return;

  const ticketNumber = customId.replace('modal_reject_', '');
  const reason = interaction.fields.getTextInputValue('reject_reason').trim();

  // 1. Authorization check
  if (!isUserAdmin(interaction)) {
    await interaction.reply({
      content: 'Akses ditolak: Hanya admin Discord yang berwenang yang boleh menolak pembayaran.',
      ephemeral: true,
    });
    return;
  }

  // 2. Fetch order
  const order = getOrderByTicket(ticketNumber);
  if (!order) {
    await interaction.reply({
      content: `Pesanan dengan Nomor Ticket ${ticketNumber} tidak ditemukan di database.`,
      ephemeral: true,
    });
    return;
  }

  // 3. Double-processing prevention check
  if (order.status !== 'Menunggu Proses Pesanan') {
    await interaction.reply({
      content: `Pesanan dengan Nomor Ticket ${ticketNumber} sudah pernah diproses sebelumnya. Status saat ini: ${order.status}.`,
      ephemeral: true,
    });
    return;
  }

  // 4. Update order in database with reason and refund notice
  const updatedOrder = updateOrderStatus(ticketNumber, 'Pembayaran Ditolak', 'VrenaStore', reason);
  if (!updatedOrder) {
    await interaction.reply({
      content: `Gagal memperbarui status pesanan ${ticketNumber} di database.`,
      ephemeral: true,
    });
    return;
  }

  const disabledRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`done_approve_${ticketNumber}`)
      .setLabel('SELESAIKAN PEMBAYARAN')
      .setStyle(ButtonStyle.Success)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId(`done_reject_${ticketNumber}`)
      .setLabel('TOLAK PEMBAYARAN')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(true)
  );

  const nowWib = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const accountLines = formatAccountDetails(order);

  // Build updated rejection embed without re-assigning .setImage so it never duplicates image
  const originalEmbed = interaction.message?.embeds[0];
  const updatedEmbed = (originalEmbed ? EmbedBuilder.from(originalEmbed) : new EmbedBuilder())
    .setColor(0xEF4444) // Rose Red
    .setAuthor({
      name: `VRENA STORE - PEMBAYARAN DITOLAK (${(order.gameName || 'TOP UP').toUpperCase()})`,
    })
    .setTitle('PESANAN TOP UP - PEMBAYARAN DITOLAK')
    .setDescription(
      `# PEMBAYARAN DITOLAK\n` +
      `-# Pesanan telah ditolak oleh admin\n\n` +
      `### NOMOR TICKET\n` +
      `\`\`\`\n${order.ticketNumber}\n\`\`\`\n` +
      `${accountLines}\n` +
      `> **GAME:** ${order.gameName || 'Game'}\n` +
      `> **PRODUK:** ${order.productName}\n` +
      `> **METODE PEMBAYARAN:** ${order.paymentMethodName || 'QRIS'}\n` +
      `> **NOMINAL PEMBAYARAN:** ${order.nominalFormatted}\n` +
      `> **WAKTU TRANSFER:** ${order.transferTime}\n\n` +
      `**STATUS PESANAN:** PEMBAYARAN DITOLAK\n` +
      `**DIVERIFIKASI OLEH:** Diverifikasi oleh VrenaStore\n` +
      `**ALASAN DITOLAK:** ${reason}\n` +
      `**CATATAN PENGEMBALIAN:** Dana akan dikembalikan sesuai nominal.\n` +
      `**WAKTU VERIFIKASI:** ${nowWib} WIB`
    )
    .setFooter({
      text: `Status: Pembayaran Ditolak • Diverifikasi oleh VrenaStore`,
    })
    .setTimestamp();

  try {
    // If the modal was opened from a message component, update message via edit
    if (interaction.message) {
      await interaction.message.edit({
        embeds: [updatedEmbed],
        components: [disabledRow],
      });
      await interaction.reply({
        content: `Pesanan ${ticketNumber} telah ditolak dengan alasan: "${reason}". Catatan: Dana akan dikembalikan sesuai nominal. Data otomatis tersinkronisasi ke Ticket Finder pembeli.`,
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: `Pesanan ${ticketNumber} telah ditolak dengan alasan: "${reason}". Status telah diperbarui di database.`,
        ephemeral: true,
      });
    }
  } catch (err: any) {
    console.error('[Discord Bot] Gagal mengupdate embed status reject via modal:', err);
    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: `Status pesanan ${ticketNumber} berhasil ditolak di database dengan alasan: "${reason}".`,
        ephemeral: true,
      });
    }
  }
}
