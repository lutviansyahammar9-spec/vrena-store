import fs from 'fs';
import path from 'path';

export type OrderStatus = 'Menunggu Proses Pesanan' | 'Pembayaran Berhasil' | 'Pembayaran Ditolak';

export interface StoredOrder {
  ticketNumber: string;
  orderId: string;
  gameId: string;
  gameName: string;
  productId: string;
  productName: string;
  productImage?: string;
  price: number;
  nominalFormatted: string;
  accountData: {
    gameId: string;
    uid?: string;
    serverId?: string;
    nickname?: string;
    username?: string;
  };
  paymentMethod: string;
  paymentMethodName: string;
  paymentProofUrl?: string;
  paymentProofName?: string;
  paymentProofPath?: string;
  transferTime: string;
  status: OrderStatus;
  rejectReason?: string;
  refundNotice?: string;
  discordMessageId?: string;
  discordChannelId?: string;
  processedBy?: string;
  processedAt?: string;
  createdAt: string;
  updatedAt: string;
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'orders.json');
const UPLOADS_DIR = path.resolve(process.cwd(), 'public', 'uploads');

function ensureDirectories() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2), 'utf-8');
  }
}

export function getAllOrders(): StoredOrder[] {
  ensureDirectories();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading orders.json:', err);
    return [];
  }
}

export function saveOrders(orders: StoredOrder[]): void {
  ensureDirectories();
  const tmpFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmpFile, JSON.stringify(orders, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

export function getOrderByTicket(ticketNumber: string): StoredOrder | undefined {
  const orders = getAllOrders();
  return orders.find(
    (o) => o.ticketNumber === ticketNumber || o.orderId === ticketNumber
  );
}

export function getOrdersByTickets(ticketNumbers: string[]): StoredOrder[] {
  const orders = getAllOrders();
  const set = new Set(ticketNumbers);
  return orders.filter((o) => set.has(o.ticketNumber) || set.has(o.orderId));
}

export function upsertOrder(order: StoredOrder): StoredOrder {
  const orders = getAllOrders();
  const index = orders.findIndex(
    (o) => o.ticketNumber === order.ticketNumber || o.orderId === order.orderId
  );
  if (index >= 0) {
    orders[index] = {
      ...orders[index],
      ...order,
      updatedAt: new Date().toISOString(),
    };
    saveOrders(orders);
    return orders[index];
  } else {
    orders.unshift(order);
    saveOrders(orders);
    return order;
  }
}

export function updateOrderStatus(
  ticketNumber: string,
  newStatus: OrderStatus,
  processedBy?: string,
  rejectReason?: string
): StoredOrder | null {
  const orders = getAllOrders();
  const index = orders.findIndex(
    (o) => o.ticketNumber === ticketNumber || o.orderId === ticketNumber
  );
  if (index === -1) return null;

  const now = new Date().toISOString();
  orders[index].status = newStatus;
  orders[index].updatedAt = now;
  orders[index].processedBy = 'VrenaStore';
  orders[index].processedAt = now;

  if (newStatus === 'Pembayaran Ditolak') {
    orders[index].rejectReason = rejectReason || 'Pembayaran tidak memenuhi ketentuan verifikasi.';
    orders[index].refundNotice = 'Dana akan dikembalikan sesuai nominal.';
  } else if (newStatus === 'Pembayaran Berhasil') {
    orders[index].rejectReason = undefined;
    orders[index].refundNotice = undefined;
  }

  saveOrders(orders);
  return orders[index];
}

export function generateUniqueTicket(): string {
  const orders = getAllOrders();
  const existingTickets = new Set(orders.map((o) => o.ticketNumber));
  let ticket = '';
  let attempts = 0;
  do {
    const rand = Math.floor(100000 + Math.random() * 900000);
    ticket = `VRN-TKT-${rand}`;
    attempts++;
  } while (existingTickets.has(ticket) && attempts < 100);
  return ticket;
}
