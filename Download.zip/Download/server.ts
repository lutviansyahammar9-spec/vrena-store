import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { initDiscordBot, sendOrderToDiscord, isDiscordReady } from './server/discordBot.js';
import {
  getAllOrders,
  getOrderByTicket,
  getOrdersByTickets,
  upsertOrder,
  generateUniqueTicket,
  StoredOrder,
} from './server/ordersDb.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  // Initialize Discord Bot
  initDiscordBot();

  // Support up to 15MB for payment proof image uploads
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));


  // Backend API route for checking game nickname (Free Fire)
  app.post('/api/check-nickname', async (req, res) => {
    try {
      const { id, zone, zone_id, server_id, game_code = 'freefire', api_key } = req.body;

      if (!id || String(id).trim() === '') {
        return res.status(400).json({
          status: false,
          message: 'User ID tidak boleh kosong',
        });
      }

      const trimmedId = String(id).trim();
      const zoneId = String(zone || zone_id || server_id || '').trim();
      const apiKey = api_key || process.env.KOKINPAY_API_KEY || '';

      // Normalize game code
      const isML = game_code === 'mobilelegend' || game_code === 'mlbb' || game_code === 'mobile_legends';

      // 1. If Mobile Legends:
      if (isML) {
        if (!zoneId) {
          return res.status(400).json({
            status: false,
            message: 'Server / Zone ID Mobile Legends wajib diisi untuk cek ID',
          });
        }

        // 1a. Try Kokinpay if API Key is configured
        if (apiKey) {
          try {
            const kokinResponse = await fetch('https://api.kokinpay.com/v1/check-nickname', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                api_key: apiKey,
                id: trimmedId,
                zone_id: zoneId,
                game_code: 'mobilelegend',
              }),
            });
            const kokinData = await kokinResponse.json();
            if (kokinData && (kokinData.status === true || kokinData.success === true)) {
              const nickname =
                kokinData.data?.nickname ||
                kokinData.data?.username ||
                kokinData.data?.name ||
                kokinData.nickname ||
                kokinData.name;
              if (nickname) {
                return res.json({
                  status: true,
                  source: 'kokinpay',
                  nickname,
                  id: trimmedId,
                  zoneId,
                  game_code: 'mobilelegend',
                });
              }
            }
          } catch (err: any) {
            console.warn('ML Kokinpay error:', err?.message);
          }
        }

        // 1b. Try open Moonton validation gateways
        const mlPromises: Promise<{ nickname: string; source: string }>[] = [];

        // Provider A: Live isan.eu.org ML checker
        mlPromises.push(
          (async () => {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 2800);
            try {
              const res = await fetch(`https://api.isan.eu.org/nickname/ml?id=${encodeURIComponent(trimmedId)}&zone=${encodeURIComponent(zoneId)}`, {
                signal: controller.signal,
              });
              clearTimeout(timer);
              if (res.ok) {
                const data = await res.json();
                if (data && (data.name || data.nickname)) {
                  return { nickname: String(data.name || data.nickname), source: 'moonton_official' };
                }
              }
            } catch {
              clearTimeout(timer);
            }
            throw new Error('ML Provider A failed');
          })()
        );

        // Provider B: Live smile.one role check
        mlPromises.push(
          (async () => {
            const controller = new AbortController();
            const timer = setTimeout(() => controller.abort(), 2800);
            try {
              const res = await fetch('https://www.smile.one/merchant/mobilelegends/checkrole', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded',
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                },
                body: `user_id=${encodeURIComponent(trimmedId)}&zone_id=${encodeURIComponent(zoneId)}&pid=26`,
                signal: controller.signal,
              });
              clearTimeout(timer);
              if (res.ok) {
                const data = await res.json();
                if (data && (data.code === 200 || data.status === 200) && (data.username || data.name || data.data)) {
                  return { nickname: String(data.username || data.name || data.data), source: 'moonton_official' };
                }
              }
            } catch {
              clearTimeout(timer);
            }
            throw new Error('ML Provider B failed');
          })()
        );

        try {
          const result = await Promise.any(mlPromises);
          return res.json({
            status: true,
            source: result.source,
            nickname: result.nickname,
            id: trimmedId,
            zoneId,
            game_code: 'mobilelegend',
          });
        } catch {
          // Both ML live gateways unreachable or not found
        }

        return res.status(404).json({
          status: false,
          message: `ID ${trimmedId} (${zoneId}) belum dapat diverifikasi otomatis oleh server Mobile Legends. Silakan isi nickname secara manual.`,
          id: trimmedId,
          zoneId,
          game_code: 'mobilelegend',
        });
      }

      // 2. Free Fire Checker
      if (apiKey) {
        try {
          const kokinResponse = await fetch('https://api.kokinpay.com/v1/check-nickname', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              api_key: apiKey,
              id: trimmedId,
              game_code: game_code,
            }),
          });
          const kokinData = await kokinResponse.json();

          if (kokinData && (kokinData.status === true || kokinData.success === true)) {
            const nickname =
              kokinData.data?.nickname ||
              kokinData.data?.username ||
              kokinData.data?.name ||
              kokinData.nickname ||
              kokinData.username ||
              kokinData.name;
            if (nickname) {
              return res.json({
                status: true,
                source: 'kokinpay',
                nickname: nickname,
                id: trimmedId,
                game_code,
              });
            }
          }
        } catch (err: any) {
          console.warn('Kokinpay API call error:', err?.message);
        }
      }

      // Query official live Free Fire database in parallel for ultra-fast real nickname resolution
      const lookupPromises: Promise<{ nickname: string; source: string }>[] = [];

      // Provider A: Live GoPay Garena Free Fire Gateway
      lookupPromises.push(
        (async () => {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 2600);
          try {
            const response = await fetch(
              `https://gopay.co.id/games/v1/order/prepare/FREEFIRE?userId=${encodeURIComponent(trimmedId)}`,
              {
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                  'Accept': 'application/json',
                },
                signal: controller.signal,
              }
            );
            clearTimeout(timer);
            if (response.ok) {
              const data = await response.json();
              if (data && data.data) {
                return { nickname: String(data.data), source: 'garena_official' };
              }
            }
          } catch {
            clearTimeout(timer);
          }
          throw new Error('Not found on Provider A');
        })()
      );

      // Provider B: Live backup Garena Free Fire ID validator
      lookupPromises.push(
        (async () => {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 2600);
          try {
            const response = await fetch(
              `https://api.isan.eu.org/nickname/ff?id=${encodeURIComponent(trimmedId)}`,
              {
                signal: controller.signal,
              }
            );
            clearTimeout(timer);
            if (response.ok) {
              const data = await response.json();
              if (data && data.name) {
                return { nickname: String(data.name), source: 'garena_official' };
              }
            }
          } catch {
            clearTimeout(timer);
          }
          throw new Error('Not found on Provider B');
        })()
      );

      try {
        const result = await Promise.any(lookupPromises);
        return res.json({
          status: true,
          source: result.source,
          nickname: result.nickname,
          id: trimmedId,
          game_code,
        });
      } catch {
        // All live providers reported not found
      }

      // If ID does not exist in Garena database
      return res.status(404).json({
        status: false,
        message: `ID ${trimmedId} tidak ditemukan di server Free Fire. Pastikan UID kamu sudah benar.`,
        id: trimmedId,
        game_code,
      });
    } catch (err: any) {
      console.error('Server error check-nickname:', err);
      return res.status(500).json({
        status: false,
        message: 'Terjadi kesalahan pada server saat mengecek ID',
      });
    }
  });

  // Support GET request as well
  app.get('/api/check-nickname', async (req, res) => {
    const id = req.query.id as string;
    const zone = (req.query.zone || req.query.zone_id || req.query.server_id) as string;
    const game_code = (req.query.game_code as string) || 'freefire';
    if (!id) {
      return res.status(400).json({ status: false, message: 'Parameter id wajib diisi' });
    }

    const trimmedId = String(id).trim();
    const zoneId = zone ? String(zone).trim() : '';

    if (game_code === 'mobilelegend' || game_code === 'mlbb') {
      try {
        const isanRes = await fetch(
          `https://api.isan.eu.org/nickname/ml?id=${encodeURIComponent(trimmedId)}&zone=${encodeURIComponent(zoneId)}`
        );
        if (isanRes.ok) {
          const isanData = await isanRes.json();
          if (isanData && (isanData.name || isanData.nickname)) {
            return res.json({
              status: true,
              source: 'moonton_official',
              nickname: isanData.name || isanData.nickname,
              id: trimmedId,
              zoneId,
              game_code: 'mobilelegend',
            });
          }
        }
      } catch {
        // fallback
      }
      return res.status(404).json({
        status: false,
        message: `ID MLBB ${trimmedId} (${zoneId}) belum dapat diverifikasi otomatis.`,
        id: trimmedId,
        game_code: 'mobilelegend',
      });
    }

    try {
      const gopayRes = await fetch(
        `https://gopay.co.id/games/v1/order/prepare/FREEFIRE?userId=${encodeURIComponent(trimmedId)}`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
          },
        }
      );
      if (gopayRes.ok) {
        const gopayData = await gopayRes.json();
        if (gopayData && gopayData.data) {
          return res.json({
            status: true,
            source: 'garena_official',
            nickname: gopayData.data,
            id: trimmedId,
            game_code,
          });
        }
      }
    } catch {
      // fallback
    }

    try {
      const isanRes = await fetch(
        `https://api.isan.eu.org/nickname/ff?id=${encodeURIComponent(trimmedId)}`
      );
      if (isanRes.ok) {
        const isanData = await isanRes.json();
        if (isanData && isanData.name) {
          return res.json({
            status: true,
            source: 'garena_official',
            nickname: isanData.name,
            id: trimmedId,
            game_code,
          });
        }
      }
    } catch {
      // fallback
    }

    return res.status(404).json({
      status: false,
      message: `ID ${trimmedId} tidak ditemukan di server Free Fire`,
      id: trimmedId,
      game_code,
    });
  });

  // Serve uploaded payment proofs statically
  const uploadsDir = path.resolve(__dirname, 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  app.use('/uploads', express.static(uploadsDir));

  // Health check endpoint with Discord status
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      discordReady: isDiscordReady(),
      time: new Date().toISOString(),
    });
  });

  // Helper function to decode base64 Data URLs
  function parseDataUrl(dataUrl: string): { buffer: Buffer; mimeType: string; extension: string } {
    const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return { buffer: Buffer.from(dataUrl, 'base64'), mimeType: 'image/jpeg', extension: 'jpg' };
    }
    const mimeType = matches[1];
    const buffer = Buffer.from(matches[2], 'base64');
    let extension = 'jpg';
    if (mimeType.includes('png')) extension = 'png';
    else if (mimeType.includes('webp')) extension = 'webp';
    else if (mimeType.includes('jpeg')) extension = 'jpg';
    return { buffer, mimeType, extension };
  }

  // In-memory concurrency locks to guarantee strictly 1 message is ever sent per ticket
  const activeTicketLocks = new Set<string>();

  // Create Order and send to Discord
  app.post('/api/orders', async (req, res) => {
    let lockedTicket: string | null = null;
    try {
      const {
        ticketNumber: clientTicket,
        orderId: clientOrderId,
        gameId,
        gameName,
        productId,
        productName,
        productImage,
        price,
        accountData = {},
        paymentMethod = 'qris',
        paymentMethodName = 'QRIS',
        paymentProofDataUrl,
        paymentProofName = 'bukti_transfer.jpg',
        transferTime,
      } = req.body;

      if (!paymentProofDataUrl || String(paymentProofDataUrl).trim() === '') {
        return res.status(400).json({
          success: false,
          message: 'Bukti transfer wajib diunggah sebelum melanjutkan.',
        });
      }

      // Check if ticket is currently locked (in-flight request)
      const existingTicket = clientTicket || clientOrderId;
      if (existingTicket && activeTicketLocks.has(existingTicket)) {
        return res.status(409).json({
          success: false,
          ticketNumber: existingTicket,
          message: 'Pesanan sedang dikirim ke Discord, harap tunggu sebentar.',
        });
      }

      // Check if this ticket was already submitted and sent to Discord (Idempotency)
      if (existingTicket) {
        const existingOrder = getOrderByTicket(existingTicket);
        if (existingOrder && existingOrder.discordMessageId) {
          // Already sent to Discord successfully! Return existing without duplicate
          return res.json({
            success: true,
            order: existingOrder,
            message: 'Pesanan sudah tercatat sebelumnya.',
          });
        }
      }

      // Generate or reuse unique ticket number
      const ticketNumber = existingTicket || generateUniqueTicket();
      const orderId = clientOrderId || ticketNumber;

      if (activeTicketLocks.has(ticketNumber)) {
        return res.status(409).json({
          success: false,
          ticketNumber,
          message: 'Pesanan sedang diproses.',
        });
      }

      activeTicketLocks.add(ticketNumber);
      lockedTicket = ticketNumber;

      // Format nominal rupiah
      const nominalFormatted = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(Number(price) || 0).replace(/\s+/g, '');

      // Format transfer time if not provided
      const nowWib = new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
      const resolvedTransferTime = transferTime || `${nowWib} WIB`;

      // Decode proof image
      const { buffer: proofBuffer, extension } = parseDataUrl(paymentProofDataUrl);
      const cleanFileName = `bukti_${ticketNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}.${extension}`;
      const savedFilePath = path.join(uploadsDir, cleanFileName);
      fs.writeFileSync(savedFilePath, proofBuffer);

      const proofPublicUrl = `/uploads/${cleanFileName}`;

      const newOrder: StoredOrder = {
        ticketNumber,
        orderId,
        gameId: gameId || 'freefire',
        gameName: gameName || 'Free Fire',
        productId: productId || '',
        productName: productName || '',
        productImage: productImage || '',
        price: Number(price) || 0,
        nominalFormatted,
        accountData: {
          gameId: gameId || 'freefire',
          uid: accountData.uid || '',
          serverId: accountData.serverId || '',
          nickname: accountData.nickname || '',
          username: accountData.username || '',
        },
        paymentMethod: paymentMethod || 'qris',
        paymentMethodName: paymentMethodName || 'QRIS',
        paymentProofUrl: proofPublicUrl,
        paymentProofName: paymentProofName || cleanFileName,
        paymentProofPath: savedFilePath,
        transferTime: resolvedTransferTime,
        status: 'Menunggu Proses Pesanan',
        createdAt: resolvedTransferTime,
        updatedAt: new Date().toISOString(),
      };

      // Send to Discord Bot - strictly 1 message per order!
      try {
        const discordResult = await sendOrderToDiscord(newOrder, proofBuffer, cleanFileName);
        newOrder.discordMessageId = discordResult.messageId;
        newOrder.discordChannelId = discordResult.channelId;
      } catch (discordErr: any) {
        console.error('[API /api/orders] Gagal mengirim pesan ke Discord:', discordErr);
        // Do not mark as complete. Return error with ticketNumber so client can retry without duplicate
        return res.status(502).json({
          success: false,
          ticketNumber,
          message: `Gagal mengirim bukti transfer ke Discord: ${discordErr.message || 'Koneksi Discord terganggu'}. Silakan coba lagi.`,
        });
      }

      // Save to persistent database
      const saved = upsertOrder(newOrder);

      return res.status(201).json({
        success: true,
        order: saved,
      });
    } catch (err: any) {
      console.error('[API /api/orders] Server error:', err);
      return res.status(500).json({
        success: false,
        message: `Terjadi kesalahan internal server: ${err.message || 'Unknown error'}`,
      });
    } finally {
      if (lockedTicket) {
        activeTicketLocks.delete(lockedTicket);
      }
    }
  });

  // Sync orders status for buyer history
  app.post('/api/orders/sync', (req, res) => {
    try {
      const { tickets = [] } = req.body;
      if (!Array.isArray(tickets) || tickets.length === 0) {
        return res.json({ success: true, orders: [] });
      }
      const matched = getOrdersByTickets(tickets);
      return res.json({
        success: true,
        orders: matched,
      });
    } catch (err: any) {
      console.error('[API /api/orders/sync] Error:', err);
      return res.status(500).json({ success: false, message: 'Gagal sinkronisasi pesanan' });
    }
  });

  // Get specific order status by ticket
  app.get('/api/orders/:ticket', (req, res) => {
    const ticket = req.params.ticket;
    const order = getOrderByTicket(ticket);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Pesanan tidak ditemukan' });
    }
    return res.json({ success: true, order });
  });

  // List all orders (for store internal check)
  app.get('/api/orders', (_req, res) => {
    const orders = getAllOrders();
    return res.json({ success: true, count: orders.length, orders });
  });

  // In development, hook Vite's connect instance as middleware
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> Full-Stack Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Error starting server:', error);
  process.exit(1);
});
